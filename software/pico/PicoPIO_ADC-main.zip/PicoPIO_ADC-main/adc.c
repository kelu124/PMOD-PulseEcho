//!
//! \file       adc.c
//! \author     Abdelrahman Ali
//! \date       2024-01-20
//!
//! \brief      adc pio.
//!

//---------------------------------------------------------------------------
// INCLUDES
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/clocks.h"
#include "hardware/pio.h"
#include "hardware/dma.h"

#include "adc.pio.h"

//---------------------------------------------------------------------------
// CONSTANTS
//---------------------------------------------------------------------------

#define PIN_BASE 0
#define SAMPLE_COUNT 16000
#define DMA_CHANNEL 0

//---------------------------------------------------------------------------
// GLOBAL VARIABLES
//---------------------------------------------------------------------------

PIO pio;
uint sm;
uint offset;
dma_channel_config dma_chan_cfg;
uint32_t buffer[SAMPLE_COUNT];

uint32_t pinPositions[] = {2, 4, 3, 6, 5, 7, 9, 13, 15, 12};

uint32_t newPositions[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

//---------------------------------------------------------------------------
// ADC INIT
//---------------------------------------------------------------------------

void pio_adc_init()
{
    pio = pio0;
    sm = pio_claim_unused_sm(pio, true);
    offset = pio_add_program(pio, &adc_program);
    adc_program_init(pio, sm, offset, PIN_BASE);
    dma_chan_cfg = dma_channel_get_default_config(DMA_CHANNEL);
    channel_config_set_read_increment(&dma_chan_cfg, false);
    channel_config_set_write_increment(&dma_chan_cfg, true);
    channel_config_set_dreq(&dma_chan_cfg, pio_get_dreq(pio, sm, false));
    pio_sm_set_enabled(pio, sm, true);
}

//---------------------------------------------------------------------------
// ADC DMA
//---------------------------------------------------------------------------

void pio_adc_dma()
{
    dma_channel_configure(DMA_CHANNEL, &dma_chan_cfg, buffer, &pio->rxf[sm], SAMPLE_COUNT, true);

    dma_channel_wait_for_finish_blocking(DMA_CHANNEL);
}

//---------------------------------------------------------------------------
// ADC MAP PINS
//---------------------------------------------------------------------------

void pio_map_non_consecutive_pins(uint32_t *buffer)
{
    for (uint32_t y = 0; y < SAMPLE_COUNT; ++y)
    {
        uint32_t targetPinMapping = 0;

        for (uint32_t i = 0; i < 10; ++i)
        {

            uint32_t pinValue = (buffer[y] >> pinPositions[i]) & 1;

            targetPinMapping |= (pinValue << newPositions[i]);
        }

        buffer[y] = targetPinMapping;
    }
}

//---------------------------------------------------------------------------
// MAIN FUNCTION
//---------------------------------------------------------------------------

int main()
{
    stdio_init_all();

    pio_adc_init();

    while (true)
    {
        while (getchar() != '1')
            ;

        pio_adc_dma();

        pio_map_non_consecutive_pins(buffer);

        printf("Start of ACQ \n");

        for (uint32_t i = 0; i < SAMPLE_COUNT; ++i)
        {
            printf("%d,", buffer[i]);
        }

        printf("\nEnd of ACQ \n");
    }

    return 0;
}

//---------------------------------------------------------------------------
// END OF FILE
//---------------------------------------------------------------------------
